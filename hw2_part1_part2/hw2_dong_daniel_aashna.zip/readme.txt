*************************************************
*  Group members: Dong Liang                    *
*		  Daniel Chia	       	        *
*		  Aashna Shah        	        *
*                                               *
*      Insructor: George Wolberg                *
*                                               *
*	    Date: 10/17/2015			*
*		 Fall 2015			*
*						*
*						*
*						*
*						*
*						*
*************************************************
